<div class="col-sm-2 col-sm-offset-1 blog-sidebar">
	<div class="sidebar-module sidebar-module-inset">
		<h4>Navigation</h4>
		<ol class="list-unstyled">
			<?php wp_list_pages( '&title_li=' ); ?>
		</ol>
	</div>
	<div class="sidebar-module">
	</div>
</div><!-- /.blog-sidebar -->
